package mainPkg;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;



public class ClientGUI extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
//Username
	private JLabel label;
	private JTextField tf;
//server si port
	private JTextField tfServer, tfPort;
//	butoane 
	private JButton login, logout, whoIsIn;
	private JTextArea ta;//chat pr zis
	private boolean connected;//conexiune
	private Client client;//clientul
	private int defaultPort;
	private String defaultHost;

	// Constructor cu host si port
	ClientGUI(String host, int port) {

		super("Chat Client");
		defaultPort = port;
		defaultHost = host;
		//partea de sus
		JPanel northPanel = new JPanel(new GridLayout(3,1));
		//server si port 
		JPanel serverAndPort = new JPanel(new GridLayout(1,5, 1, 3));
		//pt adresa si port
		tfServer = new JTextField(host);
		tfPort = new JTextField("" + port);
		tfPort.setHorizontalAlignment(SwingConstants.RIGHT);

		serverAndPort.add(new JLabel("Server Address:  "));
		serverAndPort.add(tfServer);
		serverAndPort.add(new JLabel("Port Number:  "));
		serverAndPort.add(tfPort);
		serverAndPort.add(new JLabel(""));
		
		northPanel.add(serverAndPort);

		
		label = new JLabel("Introduceti numele :", SwingConstants.CENTER);
		northPanel.add(label);
		tf = new JTextField("Anonim");
		tf.setBackground(Color.WHITE);
		northPanel.add(tf);
		add(northPanel, BorderLayout.NORTH);

	//chat pr zis
		ta = new JTextArea("Chat\n", 80, 80);
		JPanel centerPanel = new JPanel(new GridLayout(1,1));
		centerPanel.add(new JScrollPane(ta));
		ta.setEditable(false);
		add(centerPanel, BorderLayout.CENTER);

		// the 3 buttons
		login = new JButton("Login");
		login.addActionListener(this);
		logout = new JButton("Logout");
		logout.addActionListener(this);
		logout.setEnabled(false);		//trebuie sa te loghezi ca apoi sa te deloghezi
		whoIsIn = new JButton("Utilizatori online");
		whoIsIn.addActionListener(this);
		whoIsIn.setEnabled(false);		//trebuie sa te loghezi ca sa vezi cine e online

		JPanel southPanel = new JPanel();
		southPanel.add(login);
		southPanel.add(logout);
		southPanel.add(whoIsIn);
		add(southPanel, BorderLayout.SOUTH);

		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(600, 600);
		setVisible(true);
		tf.requestFocus();

	}

	//text
	void append(String str) {
		ta.append(str);
		ta.setCaretPosition(ta.getText().length() - 1);
	}
	// daca esueaza conexiunea 
	// se reseteaza toate butoanele
	void connectionFailed() {
		login.setEnabled(true);
		logout.setEnabled(false);
		whoIsIn.setEnabled(false);
		label.setText("Introduceti nume");
		tf.setText("Anonim");
		// reseteaza portul si hostname ul 
		tfPort.setText("" + defaultPort);
		tfServer.setText(defaultHost);
		
		tfServer.setEditable(false);
		tfPort.setEditable(false);
		
		tf.removeActionListener(this);
		connected = false;
	}
		
	//click 
	public void actionPerformed(ActionEvent e) {
		Object o = e.getSource();
		// daca o este butonul de logout
		if(o == logout) {
			client.sendMessage(new ChatMessage(ChatMessage.LOGOUT, ""));
			return;
		}
		// daca o este butonul de whoisin
		if(o == whoIsIn) {
			client.sendMessage(new ChatMessage(ChatMessage.WHOISIN, ""));				
			return;
		}

	
		if(connected) {
			//trimitem mesaj
			client.sendMessage(new ChatMessage(ChatMessage.MESSAGE, tf.getText()));				
			tf.setText("");
			return;
		}
		

		if(o == login) {
			// conexiune
			String username = tf.getText().trim();
			// se ignora ca nu a completat username
			if(username.length() == 0)
				return;
			//se ignora ca nu a completat asresa
			String server = tfServer.getText().trim();
			if(server.length() == 0)
				return;
		//port invalid. ignora
			String portNumber = tfPort.getText().trim();
			if(portNumber.length() == 0)
				return;
			int port = 0;
			try {
				port = Integer.parseInt(portNumber);
			}
			catch(Exception en) {
				return;   
			}

			//client cu interfata utiliz.
			client = new Client(server, port, username, this);
		
			if(!client.start()) 
				return;
			tf.setText("");
			label.setText("Adauga mesaj");
			connected = true;
			
			//disable login 
			login.setEnabled(false);
			//le activam e celelalte doua
			logout.setEnabled(true);
			whoIsIn.setEnabled(true);
			// dezact. celelalte doua
			tfServer.setEditable(false);
			tfPort.setEditable(false);
			
			tf.addActionListener(this);
		}

	}
	public static void main(String[] args) {
		new ClientGUI("localhost", 1500);
	}

}

