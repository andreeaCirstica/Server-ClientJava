package mainPkg;

import java.net.*;
import java.io.*;
import java.util.*;


public class Client  {

	// I/O de la socket
	private ObjectInputStream sInput;		
	private ObjectOutputStream sOutput;		
	private Socket socket;

	// pentru GUI
	private ClientGUI cg;
	
	//  serverul, portul si username-ul
	private String server, username;
	private int port;

	//constructor CONSOLA
	Client(String server, int port, String username) {
		//null pentru GUI
		this(server, port, username, null);
	}

	//Constructor cu GUI
	Client(String server, int port, String username, ClientGUI cg) {
		this.server = server;
		this.port = port;
		this.username = username;
		this.cg = cg;
	}
	
	public boolean start() {
		//conectare la server
		try {
			socket = new Socket(server, port);
		} 
		// daca nu se conecteaza
		catch(Exception ec) {
			display("Eroare aparuta la conectare:" + ec);
			return false;
		}
		
		String msg = "Conectat " + socket.getInetAddress() + ":" + socket.getPort();
		display(msg);
	
		//serializarea
		try
		{
			sInput  = new ObjectInputStream(socket.getInputStream());
			sOutput = new ObjectOutputStream(socket.getOutputStream());
		}
		catch (IOException eIO) {
			display("Exception creating new Input/output Streams: " + eIO);
			return false;
		}

	
		//creaza thread care asteapta serverul
		new ListenFromServer().start();
		
		try
		{
			sOutput.writeObject(username);
		}
		catch (IOException eIO) {
			display("Exceptie login : " + eIO);
			disconnect();
			return false;
		}
		//a mers
		return true;
	}

	//trimitere mesaj consola sau GUI
	private void display(String msg) {
		if(cg == null)
			System.out.println(msg);      // CONSOLA
		else
			cg.append(msg + "\n");		// in interfata
	}
	
	//trimitere mesaj catre server
	void sendMessage(ChatMessage msg) {
		try {
			sOutput.writeObject(msg);
		}
		catch(IOException e) {
			display("Exception writing to server: " + e);
		}
	}

	
	private void disconnect() {
		try { 
			if(sInput != null) sInput.close();
		}
		catch(Exception e) {} 
		try {
			if(sOutput != null) sOutput.close();
		}
		catch(Exception e) {} 
        try{
			if(socket != null) socket.close();
		}
		catch(Exception e) {}
		
		//connection failed
		if(cg != null)
			cg.connectionFailed();
			
	}
	
	public static void main(String[] args) {
	//default
		int portNumber = 1500;
		String serverAddress = "localhost";
		String userName = "Anonim";

		// depending of the number of arguments provided we fall through
		switch(args.length) {
			// > javac Client username portNumber serverAddr
			case 3:
				serverAddress = args[2];
			// > javac Client username portNumber
			case 2:
				try {
					portNumber = Integer.parseInt(args[1]);
				}
				catch(Exception e) {
					System.out.println("Port invalid.");
					System.out.println("Usage is: > java Client [username] [port] [serverAddress]");
					return;
				}
		
			case 1: 
				userName = args[0];
		//client java
			case 0:
				break;
			//invalid nr de argumente
			default:
				System.out.println("Usage is: > java Client [username] [portNumber] {serverAddress]");
			return;
		}
	//client
		Client client = new Client(serverAddress, portNumber, userName);
	
		if(!client.start())
			return;
		
		//mesaje de la tastura
		Scanner scan = new Scanner(System.in);
		//loop infinit
		while(true) {
			System.out.print("> ");
			// citeste mesaj de a utilizator
			String msg = scan.nextLine();
			// logout 
			if(msg.equalsIgnoreCase("LOGOUT")) {
				client.sendMessage(new ChatMessage(ChatMessage.LOGOUT, ""));
				// break to do the disconnect
				break;
			}
			// message WhoIsIn
			else if(msg.equalsIgnoreCase("WHOISIN")) {
				client.sendMessage(new ChatMessage(ChatMessage.WHOISIN, ""));				
			}
			else {				// default to ordinary message
				client.sendMessage(new ChatMessage(ChatMessage.MESSAGE, msg));
			}
		}
		// disconnect
		client.disconnect();	
	}

	//MULTITHREADING
	class ListenFromServer extends Thread {

		public void run() {
			while(true) {
				try {
					String msg = (String) sInput.readObject();
					
					if(cg == null) {
						System.out.println(msg);
						System.out.print("> ");
					}
					else {
						cg.append(msg);
					}
				}
				catch(IOException e) {
					display("Serverul a inchis conexiunea: " + e);
					if(cg != null) 
						cg.connectionFailed();
					break;
				}
			
				catch(ClassNotFoundException e2) {
				}
			}
		}
	}
}
